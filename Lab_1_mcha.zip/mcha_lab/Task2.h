#ifndef MCHA_LAB_TASK2_H
#define MCHA_LAB_TASK2_H
#include <vector>
#include <cmath>

double function(double x) {
  return tanh(x);
}

double der(double x) {
  return 1 / pow(cosh(x), 2);
}

std::vector<double> multiply(std::vector<double>& p1, std::vector<double>& p2) {
  std::vector<double> ans(p1.size() + p2.size() - 1, 0);
  for (int i = 0; i < p1.size(); i++) {
    for (int j = 0; j < p2.size(); j++) {
      ans[i + j] += p1[i] * p2[j];
    }
  }
  return ans;
}

void multiply_number(std::vector<double>& p, double number) {
  for (auto& i : p) {
    i *= number;
  }
}

std::vector<double> add(std::vector<double>& p1, std::vector<double>& p2) {
  std::vector<double> ans(std::max(p1.size(), p2.size()), 0);
  for (int i = 0; i < ans.size(); i++) {
    if (p1.size() > i && p2.size() > i) {
      ans[i] = p1[i] + p2[i];
    } else if (p1.size() <= i) {
      ans[i] = p2[i];
    } else {
      ans[i] = p1[i];
    }
  }
  return ans;
}

double compute(std::vector<double> p, double x_0) {
  double ans = 0;
  for (int i = 0; i < p.size(); i++) {
    ans += p[i] * pow(x_0, i);
  }
  return ans;
}

std::vector<double> delta(double(* f)(double), int n, double a, double b) {
  double h = (b - a) / (n - 1);
  std::vector<double> res(n);
  std::vector<double> ret;
  for (int i = 0; i < n; i++) {
    res[i] = f(a + i * h);
  }
  while (n > 1) {
    n--;
    for (int i = 0; i < n; i++) {
      res[i] = res[i + 1] - res[i];
    }
    ret.push_back(res[0]);
  }
  return ret;
}

std::vector<double> delta_ermit(double(* f)(double), std::vector<double>& x) {
  std::vector<double> ret;
  std::vector<double> double_x;
  for (auto& i : x) {
    double_x.push_back(i);
    double_x.push_back(i);
  }
  std::vector<double> table(2 * x.size());
  for (int i = 0; i < 2 * x.size(); i++) {
    table[i] = f(x[i / 2]);
  }
  ret.push_back(table[0]);
  int k = 2 * x.size() - 1;
  for (int i = 0; i < k; i++) {
    if (i % 2 == 0) {
      table[i] = der(x[i / 2]);
    } else {
      table[i] = (table[i + 1] - table[i]) / (double_x[i + 1] - double_x[i]);
    }
  }
  ret.push_back(table[0]);
  int d = 1;
  while (k > 1) {
    k--;
    d++;
    for (int i = 0; i < k; i++) {
      table[i] = (table[i + 1] - table[i]) / (double_x[i + d] - double_x[i]);
    }
    ret.push_back(table[0]);
  }
  return ret;
}

std::vector<double> Lagrang(double(* f)(double), std::vector<double>& x) { // работает
  std::vector<std::vector<std::vector<double>>> w(x.size(), std::vector<std::vector<double>>(x.size()));
  for (int i = 0; i < x.size(); i++) {
    for (int j = 0; j < x.size(); j++) {
      w[i][j] = {-x[j], 1};
    }
  }
  for (int i = 0; i < x.size(); i++) {
    w[i][i] = {1};
  }
  std::vector<double> ans = {0};
  for (int i = 0; i < x.size(); i++) {
    std::vector<double> polynom = {1};
    for (auto j : w[i]) {
      polynom = multiply(polynom, j);
    }
    double z = compute(polynom, x[i]);
    multiply_number(polynom, f(x[i]) / z);
    ans = add(ans, polynom);
  }
  return ans;
}
std::vector<double> equal_points(double(* f)(double),
                                 int n,
                                 double a,
                                 double b) {
  double h = (b - a) / (n - 1);
  std::vector<double> x;
  for (int i = 0; i < n; i++) {
    x.push_back(a + h * i);
  }
  return Lagrang(f, x);
}

std::vector<double> Chebushev(double(* f)(double), int n, double a, double b) { // ну вроде должно работать
  std::vector<double> x(n);
  for (int i = 0; i < n; i++) {
    x[i] = (a + b) / 2 + (b - a) / 2 * cos(M_PI * (2 * i + 1) / (2 * n));
  }
  return Lagrang(f, x);
}

std::vector<double> Ermit(double(* f)(double), std::vector<double>& x) {
  std::vector<double> double_x;
  for (auto& i : x) {
    double_x.push_back(i);
    double_x.push_back(i);
  }
  std::vector<double> delta = delta_ermit(f, x);
  std::vector<double> ans = {0};
  std::vector<double> polynom = {1};
  for (int i = 0; i < delta.size(); i++) {
    std::vector<double> adding = polynom;
    multiply_number(adding, delta[i]);
    ans = add(ans, adding);
    std::vector<double> m = {-double_x[i], 1};
    polynom = multiply(polynom, m);
  }
  return ans;
}

std::pair<double, int> count_100_equal(double(* f)(double), double a, double b, double x_0) {
  std::vector<double> x;
  int index;
  for (int i = 0; i < 100; i++) {
    x.push_back(a + (b - a) / 99 * i);
  }
  if (x_0 <= a) {
    index = 0;
  }
  for (int i = 0; i < x.size() - 1; i++) {
    if (x[i] <= x_0 && x_0 < x[i + 1]) {
      index = i;
      break;
    }
  }
  if (x_0 >= b) {
    index = x.size() - 1;
  }
  int d = 0;
  double result = f(x[index]);
  while (index - d >= 0 && index + d + 1 < 100) {
    std::vector<double> polynom = equal_points(f, 2 * d + 2, x[index - d], x[index + d + 1]);
    if (fabs(result - compute(polynom, x_0)) < 10e-10) {
      return {result, 2 * d + 2};
    }
    result = compute(polynom, x_0);
    d++;
  }
  while (d < 100) {
    if (index - d < 0) {
      std::vector<double> polynom = equal_points(f, 2 * d + 2, x[0], x[2 * d + 1]);
      if (fabs(result - compute(polynom, x_0)) < 10e-10) {
        return {result, 2 * d + 2};
      }
      result = compute(polynom, x_0);
      d++;
    }
    if (index + d + 1 < 100) {
      std::vector<double> polynom = equal_points(f, 2 * d + 2, x[99 - 2 * d], x[99]);
      if (fabs(result - compute(polynom, x_0)) < 10e-10) {
        return {result, 2 * d + 2};
      }
      result = compute(polynom, x_0);
      d++;
    }
  }
  return {result, d};
}

std::vector<double> three_diagonal(std::vector<double>& matrix, std::vector<double>& b) {
  for (int i = 0; i < matrix.size() - 5; i += 3) {
    if (fabs(matrix[i]) < fabs(matrix[i + 3])) {
      std::swap(matrix[i], matrix[i + 3]);
      std::swap(matrix[i + 1], matrix[i + 4]);
      std::swap(matrix[i + 2], matrix[i + 5]);
      std::swap(b[(i / 3)], b[(i / 3) + 1]);
    }
    double k = -1 * (matrix[i + 3] / matrix[i]);
    matrix[i + 3] = matrix[i + 4] + k * matrix[i + 1];
    matrix[i + 4] = matrix[i + 5] + k * matrix[i + 2];
    matrix[i + 5] = 0;
    b[(i / 3) + 1] += k * b[i / 3];
  }
  b[b.size() - 1] /= matrix[matrix.size() - 3];
  b[b.size() - 2] -= matrix[matrix.size() - 5] * b[b.size() - 1];
  b[b.size() - 2] /= matrix[matrix.size() - 6];
  for (int i = b.size() - 3; i >= 0; i--) {
    b[i] += b[i + 1] * (-1) * matrix[3 * i + 1];
    b[i] += b[i + 2] * (-1) * matrix[3 * i + 2];
    b[i] /= matrix[3 * i];
  }
  return b;
}

std::vector<std::vector<double>> splain(double(* f)(double), std::vector<double>& x) {
  std::vector<std::vector<double>> ans;
  double h = x[1] - x[0];
  double a = h / 6;
  double b = -2 * h / 3;
  double c = h / 6;
  std::vector<double> d(x.size() - 2);
  for (int i = 1; i < x.size() - 1; i++) {
    d[i - 1] = (f(x[i + 1]) - f(x[i])) / h - (f(x[i]) - f(x[i - 1])) / h;
  }
  std::vector<double> matrix;
  matrix.push_back(-b);
  matrix.push_back(c);
  matrix.push_back(0);
  for (int i = 1; i < d.size() - 1; i++) {
    matrix.push_back(a);
    matrix.push_back(-b);
    matrix.push_back(c);
  }
  matrix.push_back(a);
  matrix.push_back(-b);
  matrix.push_back(0);
  std::vector<double> M;
  M.push_back(0);
  for (auto& i : three_diagonal(matrix, d)) {
    M.push_back(i);
  }
  M.push_back(0);
  for (int i = 1; i < x.size(); i++) {
    double c_1 = (f(x[i]) - f(x[i - 1])) / h - h / 6 * (M[i] - M[i - 1]) - (x[i] + x[i - 1]) / 2 * M[i - 1];
    double c_2 = f(x[i - 1]) - c_1 * x[i - 1] - pow(x[i - 1], 2) * M[i - 1] / 2;
    std::vector<double> s = {-x[i - 1], 1};
    std::vector<double> w = s;
    double z = compute(s, x[i]);
    s = multiply(s, s);
    s = multiply(s, w);
    multiply_number(s, (M[i] - M[i - 1]) / (6 * z));
    std::vector<double> adding = {c_2, c_1, M[i - 1] / 2};
    s = add(s, adding);
    ans.push_back(s);
  }
  return ans;
}

std::vector<double> square(double(* f)(double), int n, std::vector<double>& x) {
  std::vector<std::vector<double>> table(2 * n + 1, std::vector<double>(x.size()));
  for (int row = 0; row < 2 * n + 1; row++) {
    for (int col = 0; col < x.size(); col++) {
      table[row][col] = pow(x[col], row);
    }
  }
  std::vector<double> phi(2 * n + 1, 0);
  for (int row = 0; row < table.size(); row++) {
    for (int col = 0; col < table[0].size(); col++) {
      phi[row] += table[row][col];
    }
  }
  std::vector<std::vector<double>> matrix(n + 1, std::vector<double>(n + 1));
  for (int row = 0; row < matrix.size(); row++) {
    for (int col = 0; col < matrix.size(); col++) {
      matrix[row][col] = phi[row + col];
    }
  }
  std::vector<double> b(n + 1, 0);
  for (int row = 0; row < b.size(); row++) {
    for (int col = 0; col < x.size(); col++) {
      b[row] += table[row][col] * f(x[col]);
    }
  }
  std::vector<double> polynom = solve(matrix, b);
  return polynom;
}

#endif //MCHA_LAB_TASK2_H
