
#ifndef MCHA_LAB_TASK3_H
#define MCHA_LAB_TASK3_H
#include "Task2.h"

double double_function(double x, double y) {
  return (x + y) * (cos(x) + cos(y));
}

std::vector<double> double_interpolation(double(* f)(double, double), std::vector<double>& x, std::vector<double>& y) {
  std::vector<double> ans_polynom(x.size() * y.size(), 0);
  std::vector<std::vector<std::vector<double>>> w_x(x.size(), std::vector<std::vector<double>>(x.size()));
  for (int i = 0; i < x.size(); i++) {
    for (int j = 0; j < x.size(); j++) {
      w_x[i][j] = {-x[j], 1};
    }
  }
  for (int i = 0; i < x.size(); i++) {
    w_x[i][i] = {1};
  }
  std::vector<std::vector<std::vector<double>>> w_y(y.size(), std::vector<std::vector<double>>(y.size()));
  for (int i = 0; i < y.size(); i++) {
    for (int j = 0; j < y.size(); j++) {
      w_y[i][j] = {-y[j], 1};
    }
  }
  for (int i = 0; i < y.size(); i++) {
    w_y[i][i] = {1};
  }
  for (int i = 0; i < x.size(); i++) {
    for (int j = 0; j < y.size(); j++) {
      std::vector<double> polynom_x = {1};
      std::vector<double> polynom_y = {1};
      for (auto p : w_x[i]) {
        polynom_x = multiply(polynom_x, p); // w'_x
      }
      double z = compute(polynom_x, x[i]);
      for (auto p : w_y[j]) {
        polynom_y = multiply(polynom_y, p); // w'_y
      }
      double q = compute(polynom_y, y[j]);
      multiply_number(polynom_x, f(x[i], y[j]) / (z * q));
      for (int k = 0; k < ans_polynom.size(); k++) {
        ans_polynom[k] += polynom_x[k / y.size()] * polynom_y[k % y.size()];
      }
    }
  }
  return ans_polynom;
}

std::vector<std::vector<std::vector<double>>> double_splain (double(*f)(double, double), std::vector<double>& x, std::vector<double>& y) {
  double h = x[1] - x[0];
  double t = y[1] - y[0];
  std::vector<std::vector<std::vector<double>>> res((x.size() - 1), std::vector<std::vector<double>>(y.size() - 1));
  std::vector<double> ans_splain (16);
  std::vector<std::vector<std::vector<double>>> deltas(x.size(), std::vector<std::vector<double>>(y.size()));
  std::vector<std::vector<std::vector<double>>> polynoms(x.size(), std::vector<std::vector<double>>(y.size()));
  std::vector<std::vector<double>> M (y.size());
  for (int j = 0; j < y.size(); j++) {
    std::vector<double> d(x.size() - 2);
    for (int i = 1; i < x.size() - 1; i++) {
      d[i - 1] = (f(x[i + 1], y[j]) - f(x[i], y[j])) / h - (f(x[i], y[j]) - f(x[i - 1], y[j])) / h;
    }
    std::vector<double> matrix;
    double a = h / 6;
    double b = -2 * h / 3;
    double c = h / 6;
    matrix.push_back(-b);
    matrix.push_back(c);
    matrix.push_back(0);
    for (int i = 1; i < d.size() - 1; i++) {
      matrix.push_back(a);
      matrix.push_back(-b);
      matrix.push_back(c);
    }
    if (d.size() == 1) {
      M[j].push_back(0);
      M[j].push_back(d[0] / (-b));
      M[j].push_back(0);
    }
    if (d.size() > 1) {
      matrix.push_back(a);
      matrix.push_back(-b);
      matrix.push_back(0);
      M[j].push_back(0);
      for (auto& i : three_diagonal(matrix, d)) {
        M[j].push_back(i);
      }
      M[j].push_back(0);
    }
  }
  std::vector<std::vector<double>> K (x.size());
  for (int i = 0; i < x.size(); i++) {
    std::vector<double> d(y.size() - 2);
    for (int j = 1; j < y.size() - 1; j++) {
      d[j - 1] = (M[j + 1][i] - M[j][i]) / t - (M[j][i] - M[j - 1][i]) / t;
    }
    std::vector<double> matrix;
    double a = t / 6;
    double b = -2 * t / 3;
    double c = t / 6;
    matrix.push_back(-b);
    matrix.push_back(c);
    matrix.push_back(0);
    for (int j = 1; j < d.size() - 1; j++) {
      matrix.push_back(a);
      matrix.push_back(-b);
      matrix.push_back(c);
    }
    if (d.size() == 1) {
      K[i].push_back(0);
      K[i].push_back(d[0] / (-b));
      K[i].push_back(0);
    }
    if (d.size() > 1) {
      matrix.push_back(a);
      matrix.push_back(-b);
      matrix.push_back(0);
      K[i].push_back(0);
      for (auto& j : three_diagonal(matrix, d)) {
        K[i].push_back(i);
      }
      K[i].push_back(0);
    }
  }
  std::vector<std::vector<double>> L (x.size());
  for (int i = 0; i < x.size(); i++) {
    std::vector<double> d(y.size() - 2);
    for (int j = 1; j < y.size() - 1; j++) {
      d[j - 1] = (f(x[i], y[j + 1]) - f(x[i], y[j])) / t - (f(x[i], y[j]) - f(x[i], y[j - 1])) / t;
    }
    std::vector<double> matrix;
    double a = t / 6;
    double b = -2 * t / 3;
    double c = t / 6;
    matrix.push_back(-b);
    matrix.push_back(c);
    matrix.push_back(0);
    for (int j = 1; j < d.size() - 1; j++) {
      matrix.push_back(a);
      matrix.push_back(-b);
      matrix.push_back(c);
    }
    if (d.size() == 1) {
      L[i].push_back(0);
      L[i].push_back(d[0] / (-b));
      L[i].push_back(0);
    }
    if (d.size() > 1) {
      matrix.push_back(a);
      matrix.push_back(-b);
      matrix.push_back(0);
      L[i].push_back(0);
      for (auto& j : three_diagonal(matrix, d)) {
        L[i].push_back(i);
      }
      L[i].push_back(0);
    }
  }
  for(int i = 0; i < x.size(); i++) {
    for (int j = 1; j < y.size(); j++) {
      std::vector<double> splayin_y = {0};
      std::vector<double> delta = {0};
      std::vector<double> polynom = {y[j], -1};
      std::vector<double> s = polynom;
      std::vector<double> c = polynom;
      polynom = multiply(polynom, polynom);
      polynom = multiply(polynom, s);
      std::vector<double> d = polynom;
      multiply_number(d, L[i][j - 1] / (6 * t));
      delta = add(delta, d);
      multiply_number(polynom, K[i][j - 1] / (6 * t));
      splayin_y = add(splayin_y, polynom);
      multiply_number(c, f(x[i], y[j - 1]) / t - L[i][j - 1] * t/ 6);
      multiply_number(s, M[j - 1][i] / t - L[i][j - 1] * t / 6);
      splayin_y = add(splayin_y, s);
      delta = add(delta, c);
      polynom = {0};
      polynom = {-y[j - 1], 1};
      s = polynom;
      c = polynom;
      polynom = multiply(polynom, polynom);
      polynom = multiply(polynom, s);
      d = polynom;
      multiply_number(d, L[i][j] / (6 * t));
      multiply_number(polynom, K[i][j] / (6 * t));
      splayin_y = add(splayin_y, polynom);
      delta = add(delta, d);
      multiply_number(s, M[j][i] / t - L[i][j] * t / 6);
      multiply_number(c, f(x[i], y[j]) / t - L[i][j] * t / 6);
      splayin_y = add(splayin_y, s);
      delta = add(delta, c);

      deltas[i][j] = delta;
      polynoms[i][j] = splayin_y;

    }
  }

  for (int i = 1; i < x.size(); i++) {
    for (int j = 1; j < y.size(); j++) {
      for(auto& r : ans_splain) {
        r = 0;
      }
      std::vector<double> polynom_x = {x[i], -1};
      std::vector<double> s = polynom_x;
      polynom_x = multiply(polynom_x, s);
      polynom_x = multiply(polynom_x, s);
      s.push_back(0);
      s.push_back(0);
      multiply_number(polynom_x, 1 / (6 * h));
      for (int k = 0; k < ans_splain.size(); k++) {
        ans_splain[k] += polynom_x[k / 4] * polynoms[i - 1][j][k % 4];
      }

      polynom_x = {-x[i - 1], 1};
      std::vector<double> c = polynom_x;
      polynom_x = multiply(polynom_x, c);
      polynom_x = multiply(polynom_x, c);
      c.push_back(0);
      c.push_back(0);
      multiply_number(polynom_x, 1 / (6 * h));
      for (int k = 0; k < ans_splain.size(); k++) {
        ans_splain[k] += polynom_x[k / 4] * polynoms[i][j][k % 4];
      }

      std::vector<double> polynom_y = deltas[i][j];
      std::vector<double> adding_y = polynoms[i][j];
      multiply_number(adding_y, -pow(h, 2) / 6);
      polynom_y = add(polynom_y, adding_y);
      multiply_number(c, 1 / h);
      for (int k = 0; k < ans_splain.size(); k++) {
        ans_splain[k] += c[k / 4] * polynom_y[k % 4];
      }

      polynom_y = deltas[i - 1][j];
      adding_y = polynoms[i - 1][j];
      multiply_number(adding_y, -pow(h, 2) / 6);
      polynom_y = add(polynom_y, adding_y);
      multiply_number(s, 1 / h);
      for (int k = 0; k < ans_splain.size(); k++) {
        ans_splain[k] += s[k / 4] * polynom_y[k % 4];
      }
      res[i - 1][j - 1] = ans_splain;
    }
  }
 return res;
}

#endif //MCHA_LAB_TASK3_H
