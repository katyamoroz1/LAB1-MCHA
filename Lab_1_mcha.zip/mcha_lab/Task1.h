#ifndef MCHA_LAB_TASK1_H
#define MCHA_LAB_TASK1_H
#include <vector>
#include <cmath>

const double EPS = 10e-10;

double function_0(double x, double y) {
  return (x + 1) / (y - 5) + pow(x, 2) - 13;
}

double function_1(double x, double y) {
  return cos(2 * x) - 6 * y;
}

double der_0_x(double x, double y) {
  return 2 * x + 1 / (y - 5);
}

double der_0_y(double x, double y) {
  return -(x + 1) / pow((y - 5), 2);
}

double der_1_x(double x, double y) {
  return -2 * sin(2 * x);
}

double der_1_y(double x, double y) {
  return -6;
}

double Derivative_x(double(* f)(double, double), double x, double y) {
  return (f(x + EPS, y) - f(x, y)) / EPS;
}

double Derivative_y(double(* f)(double, double), double x, double y) {
  return (f(x, y + EPS) - f(x, y)) / EPS;
}


std::vector<std::vector<double>> Yakobi(double x_1, double x_2) {
  std::vector<std::vector<double>> Yakobian(2, std::vector<double>(2));
  Yakobian[0][0] = der_0_x(x_1, x_2);
  Yakobian[0][1] = der_0_y(x_1, x_2);
  Yakobian[1][0] = der_1_x(x_1, x_2);
  Yakobian[1][1] = der_1_y(x_1, x_2);
  return Yakobian;
}

std::vector<std::vector<double>> Yakobi_discreet(double(* f_1)(double, double),
                                                 double(* f_2)(double, double),
                                                 double x_1,
                                                 double x_2) {
  std::vector<std::vector<double>> Yakobian(2, std::vector<double>(2));
  Yakobian[0][0] = Derivative_x(f_1, x_1, x_2);
  Yakobian[0][1] = Derivative_y(f_1, x_1, x_2);
  Yakobian[1][0] = Derivative_x(f_2, x_1, x_2);
  Yakobian[1][1] = Derivative_y(f_2, x_1, x_2);
  return Yakobian;
}

void add_rows(std::vector<double>& first, std::vector<double>& second, double k) {
  for (int i = 0; i < first.size(); i++) {
    first[i] += k * second[i];
  }
}

std::vector<double> solve(std::vector<std::vector<double>>& matrix, std::vector<double>& b) {
  for (int col = 0; col < matrix.size(); col++) {
    double diag = matrix[col][col];
    b[col] = b[col] / diag;
    for (int j = 0; j < matrix.size(); j++) {
      matrix[col][j] = matrix[col][j] / diag;
    }
    for (int j = col + 1; j < matrix.size(); j++) {
      b[j] += b[col] * (-1 * matrix[j][col]);
      add_rows(matrix[j], matrix[col], -1 * matrix[j][col]);
    }
  }
  for (int i = matrix.size(); i >= 0; i--) {
    for (int j = i + 1; j < matrix.size(); j++) {
      b[i] += b[j] * (-1 * matrix[i][j]);
    }
  }
  for (int i = matrix.size(); i >= 0; i--) {
    for (int j = i + 1; j < matrix.size(); j++) {
      add_rows(matrix[i], matrix[j], -1 * matrix[i][j]);
    }
  }
  return b;
}

std::pair<std::vector<double>, int> Newton(double(* f_1)(double, double),
                                    double(* f_2)(double, double),
                                    std::vector<double> x) {
  int count = 1;
  std::vector<std::vector<double>> Yakobian = Yakobi(x[0], x[1]);
  std::vector<double> b = {-f_1(x[0], x[1]), -f_2(x[0], x[1])};
  std::vector<double> delta_x = solve(Yakobian, b);
  while (std::max(fabs(delta_x[0]), fabs(delta_x[1])) > 10e-6) {
    x = {x[0] + delta_x[0], x[1] + delta_x[1]};
    Yakobian = Yakobi(x[0], x[1]);
    b = {-f_1(x[0], x[1]), -f_2(x[0], x[1])};
    delta_x = solve(Yakobian, b);
    count++;
  }
  return {x, count};
}

std::pair<std::vector<double>, int> Newton_discreet(double(* f_1)(double, double),
                                    double(* f_2)(double, double),
                                    std::vector<double> x) {
  int count = 1;
  std::vector<std::vector<double>> Yakobian = Yakobi_discreet(f_1, f_2, x[0], x[1]);
  std::vector<double> b = {-f_1(x[0], x[1]), -f_2(x[0], x[1])};
  std::vector<double> delta_x = solve(Yakobian, b);
  while (std::max(fabs(delta_x[0]), fabs(delta_x[1])) > 10e-15) {
    x = {x[0] + delta_x[0], x[1] + delta_x[1]};
    Yakobian = Yakobi_discreet(f_1, f_2, x[0], x[1]);
    b = {-f_1(x[0], x[1]), -f_2(x[0], x[1])};
    delta_x = solve(Yakobian, b);
    count++;
  }
  return {x, count};
}

#endif //MCHA_LAB_TASK1_H
