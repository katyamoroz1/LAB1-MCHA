#include <iostream>
#include <iomanip>
#include <fstream>
#include <ctime>
#include <algorithm>
#include <random>
#include "Task1.h"
#include "Task2.h"
#include "Task3.h"

std::ofstream out("output.txt");

int main() {
  out << std::fixed << std::setprecision(20);

  //////////////////////// task 1 /////////////////////////////////////////////

  out << "Task 1" << std::endl;
  out << std::endl;

  auto newton = Newton(function_0, function_1, {3.5, 0.5});
  out << newton.second << " iterations; point :  " << newton.first[0] << "   " << newton.first[1] << std::endl;
  auto discreet = Newton_discreet(function_0, function_1, {3.5, 0.5});
  out << discreet.second << " iteration; point : " << discreet.first[0] << "   " << discreet.first[1] << std::endl;

  out << "function in this point " << function_0(newton.first[0], newton.first[1]) << ",  "
      << function_1(newton.first[0], newton.first[1]) << std::endl;
  out << "function in this point " << function_0(discreet.first[0], discreet.first[1]) << ",  "
      << function_1(discreet.first[0], discreet.first[1]) << std::endl;

  out << std::endl;

  auto newton_2 = Newton(function_0, function_1, {-3.5, 0.5});
  out << newton_2.second << " iterations; point :  " << newton_2.first[0] << "   " << newton_2.first[1] << std::endl;
  auto discreet_2 = Newton_discreet(function_0, function_1, {-3.5, 0.5});
  out << discreet_2.second << " iteration; point : " << discreet_2.first[0] << "   " << discreet_2.first[1]
      << std::endl;

  out << "function in this point " << function_0(newton_2.first[0], newton_2.first[1]) << ",  "
      << function_1(newton_2.first[0], newton_2.first[1]) << std::endl;
  out << "function in this point " << function_0(discreet_2.first[0], discreet_2.first[1]) << ",  "
      << function_1(discreet_2.first[0], discreet_2.first[1]) << std::endl;

  ///////////////////////////////////////////  task 2  ///////////////////////////////////////////////////////////////

  out << std::endl;
  out << "Task 2.1" << std::endl;
  out << std::endl;

  out << "6 points,  ";
  clock_t start = clock();
  auto equal_6 = equal_points(function, 6, -5, 5);
  clock_t end = clock();
  double seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << " time " << seconds << "sec: " << std::endl;
  for (int i = 0; i < equal_6.size(); i++) {
    out << equal_6[i] << "x^" << i << " + ";
  }
  out << std::endl;

  out << "12 points, ";
  start = clock();
  auto equal_12 = equal_points(function, 12, -5, 5);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << " time " << seconds << "sec: " << std::endl;
  for (int i = 0; i < equal_12.size(); i++) {
    out << equal_12[i] << "x^" << i << " + ";
  }
  out << std::endl;

  out << "18 points, ";
  start = clock();
  auto equal_18 = equal_points(function, 18, -5, 5);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << " time " << seconds << "sec: " << std::endl;
  for (int i = 0; i < equal_18.size(); i++) {
    out << equal_18[i] << "x^" << i << " + ";
  }
  out << std::endl;

  out << std::endl;
  out << "Task 2.2" << std::endl;
  out << std::endl;

  out << "6 points, ";
  start = clock();
  auto cheb_6 = Chebushev(function, 6, -5, 5);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << " time " << seconds << "sec: " << std::endl;
  for (int i = 0; i < cheb_6.size(); i++) {
    out << cheb_6[i] << "x^" << i << " + ";
  }
  out << std::endl;

  out << "12 points, ";
  auto cheb_12 = Chebushev(function, 12, -5, 5);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << " time " << seconds << "sec: " << std::endl;
  for (int i = 0; i < cheb_12.size(); i++) {
    out << cheb_12[i] << "x^" << i << " + ";
  }
  out << std::endl;

  out << "18 points, ";
  auto cheb_18 = Chebushev(function, 18, -5, 5);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << " time " << seconds << "sec: " << std::endl;
  for (int i = 0; i < cheb_18.size(); i++) {
    out << cheb_18[i] << "x^" << i << " + ";
  }
  out << std::endl;

  out << std::endl;
  out << "Task 2.3" << std::endl;
  out << std::endl;

  out << "6 points, ";
  std::vector<double> x;
  for (int i = 0; i < 6; i++) {
    x.push_back(-5 + double(10 * i) / 5);
  }
  start = clock();
  auto eq_ermit_6 = Ermit(function, x);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << " time " << seconds << "sec: " << std::endl;
  for (int i = 0; i < eq_ermit_6.size(); i++) {
    out << eq_ermit_6[i] << "x^" << i << " + ";
  }
  out << std::endl;

  out << "12 points, ";
  x.clear();
  for (int i = 0; i < 12; i++) {
    x.push_back(-5 + double(10 * i) / 11);
  }
  auto eq_ermit_12 = Ermit(function, x);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << " time " << seconds << "sec: " << std::endl;
  for (int i = 0; i < eq_ermit_12.size(); i++) {
    out << eq_ermit_12[i] << "x^" << i << " + ";
  }
  out << std::endl;

  out << "18 points, ";
  x.clear();
  for (int i = 0; i < 18; i++) {
    x.push_back(-5 + double(10 * i) / 17);
  }
  auto eq_ermit_18 = Ermit(function, x);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << " time " << seconds << "sec: " << std::endl;
  for (int i = 0; i < eq_ermit_18.size(); i++) {
    out << eq_ermit_18[i] << "x^" << i << " + ";
  }
  out << std::endl;

  out << std::endl;
  out << "Task 2.4" << std::endl;
  out << std::endl;

  x.clear();
  out << "6 points, ";
  for (int i = 0; i < 6; i++) {
    x.push_back(5 * cos(M_PI * (2 * i + 1) / (2 * 6)));
  }
  start = clock();
  auto ch_ermit_6 = Ermit(function, x);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << " time " << seconds << "sec: " << std::endl;
  for (int i = 0; i < ch_ermit_6.size(); i++) {
    out << ch_ermit_6[i] << "x^" << i << " + ";
  }
  out << std::endl;

  out << "12 points, ";
  x.clear();
  for (int i = 0; i < 12; i++) {
    x.push_back(5 * cos(M_PI * (2 * i + 1) / (2 * 12)));
  }
  auto ch_ermit_12 = Ermit(function, x);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << " time " << seconds << "sec: " << std::endl;
  for (int i = 0; i < ch_ermit_12.size(); i++) {
    out << ch_ermit_12[i] << "x^" << i << " + ";
  }
  out << std::endl;

  out << "18 points, ";
  x.clear();
  for (int i = 0; i < 18; i++) {
    x.push_back(5 * cos(M_PI * (2 * i + 1) / (2 * 18)));
  }
  auto ch_ermit_18 = Ermit(function, x);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << " time " << seconds << "sec: " << std::endl;
  for (int i = 0; i < ch_ermit_18.size(); i++) {
    out << ch_ermit_18[i] << "x^" << i << " + ";
  }
  out << std::endl;

  out << std::endl;
  out << "Task 2.5" << std::endl;
  out << std::endl;

  auto point_1 = count_100_equal(function, -5, 5, sqrt(2) / 2);
  out << "Function at sqrt(2)/2 point: " << point_1.first << std::endl;
  out << "Number of points in polynom: " << point_1.second << std::endl;

  auto point_2 = count_100_equal(function, -5, 5, M_PI / 7);
  out << "Function at PI/7 point: " << point_2.first << std::endl;
  out << "Number of points in polynom: " << point_2.second << std::endl;

  out << std::endl;
  out << "Task 2.6" << std::endl;
  out << std::endl;

  x.clear();
  for (int i = 0; i < 6; i++) {
    x.push_back(-5 + double(10 * i) / 5);
  }
  out << "Six points" << std::endl;
  start = clock();
  std::vector<std::vector<double>> splains = splain(function, x);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  for (int k = 0; k < splains.size(); k++) {
    out << "Splain where x in [" << x[k] << ", " << x[k + 1] << "] : ";
    for (int i = 0; i < splains[k].size(); i++) {
      out << splains[k][i] << "x^" << i << " + ";
    }
    out << std::endl;
  }
  out << "time of splain: " << seconds << "sec" << std::endl;

  x.clear();
  for (int i = 0; i < 12; i++) {
    x.push_back(-5 + double(10 * i) / 11);
  }
  out << "Twelve points" << std::endl;
  start = clock();
  splains = splain(function, x);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  for (int k = 0; k < splains.size(); k++) {
    out << "Splain where x in [" << x[k] << ", " << x[k + 1] << "] : ";
    for (int i = 0; i < splains[k].size(); i++) {
      out << splains[k][i] << "x^" << i << " + ";
    }
    out << std::endl;
  }
  out << "time of splain: " << seconds << "sec" << std::endl;

  x.clear();
  for (int i = 0; i < 18; i++) {
    x.push_back(-5 + double(10 * i) / 17);
  }
  out << "Eighteen points" << std::endl;
  start = clock();
  splains = splain(function, x);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  for (int k = 0; k < splains.size(); k++) {
    out << "Splain where x in [" << x[k] << ", " << x[k + 1] << "] : ";
    for (int i = 0; i < splains[k].size(); i++) {
      out << splains[k][i] << "x^" << i << " + ";
    }
    out << std::endl;
  }
  out << "time of splain: " << seconds << "sec" << std::endl;

  out << std::endl;
  out << "Task 2.7" << std::endl;
  out << std::endl;

  x.clear();
  for (int i = 0; i < 100; i++) {
    double temp = -5 + static_cast <double> (rand() % 10000) / 1000;
    x.push_back(temp);
  }
  std::sort(x.begin(), x.end());

  out << "n = 1";
  start = clock();
  auto square_polynom = square(function, 1, x);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << ", time " << seconds << "sec" << std::endl;
  for (int i = 0; i < square_polynom.size(); i++) {
    out << square_polynom[i] << "x^" << i << " + ";
  }
  out << std::endl;

  out << "n = 2";
  start = clock();
  square_polynom = square(function, 2, x);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << ", time " << seconds << "sec" << std::endl;
  for (int i = 0; i < square_polynom.size(); i++) {
    out << square_polynom[i] << "x^" << i << " + ";
  }
  out << std::endl;

  out << "n = 4";
  start = clock();
  square_polynom = square(function, 4, x);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << ", time " << seconds << "sec" << std::endl;
  for (int i = 0; i < square_polynom.size(); i++) {
    out << square_polynom[i] << "x^" << i << " + ";
  }
  out << std::endl;

  out << "n = 6";
  start = clock();
  square_polynom = square(function, 6, x);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << ", time " << seconds << "sec" << std::endl;
  for (int i = 0; i < square_polynom.size(); i++) {
    out << square_polynom[i] << "x^" << i << " + ";
  }
  out << std::endl;

///////////////////////////////////// task 3 ///////////////////////////////////////////////////////////////

  x.clear();
  std::vector<double> y;
  for (int i = 0; i < 6; i++) {
    x.push_back(-5.5 + double(i * 11) / 5);
    y.push_back(-5.5 + double(i * 11) / 5);
  }

  out << std::endl;
  out << "Task 3.1" << std::endl;
  out << std::endl;
  out << "6x6 points, time ";
  start = clock();
  auto d = double_interpolation(double_function, x, y);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << seconds << "sec " << std::endl;
  for (int i = 0; i < 6; i++) {
    for (int j = 0; j < 6; j++) {
      out << d[i + j * 6] << " x ^ " << j << " * y ^" << i << " + ";
    }
  }

  x.clear();
  y.clear();
  for (int i = 0; i < 12; i++) {
    x.push_back(-5.5 + double(i * 11) / 11);
    y.push_back(-5.5 + double(i * 11) / 11);
  }

  out << std::endl;
  out << "12x12 points, time ";
  start = clock();
  auto d_12 = double_interpolation(double_function, x, y);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << seconds << "sec " << std::endl;
  for (int i = 0; i < 12; i++) {
    for (int j = 0; j < 12; j++) {
      out << d_12[i + j * 12] << " x ^" << j << " * y ^ " << i << " + ";
    }
  }

  x.clear();
  y.clear();
  for (int i = 0; i < 18; i++) {
    x.push_back(-5.5 + double(i * 11) / 17);
    y.push_back(-5.5 + double(i * 11) / 17);
  }

  out << std::endl;
  out << "18x18 points, time ";
  start = clock();
  auto d_18 = double_interpolation(double_function, x, y);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << seconds << " : " << std::endl;
  for (int i = 0; i < 18; i++) {
    for (int j = 0; j < 18; j++) {
      out << d_18[i + j * 18] << " x ^" << j << " * y ^ " << i << " + ";
    }
  }
  out << std::endl;

  out << std::endl;
  out << "Task 3.2" << std::endl;
  out << std::endl;

  x.clear();
  y.clear();
  for (int i = 0; i < 6; i++) {
    x.push_back(-5.5 + double(i * 11) / 5);
    y.push_back(-5.5 + double(i * 11) / 5);
  }

  out << "6x6, time : ";
  start = clock();
  auto splain = double_splain(double_function, x, y);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << seconds << "sec " << std::endl;
  for (int i = 0; i < x.size() - 1; i++) {
    for (int j = 0; j < y.size() - 1; j++) {
      auto s = splain[i][j];
      out << "Splain with x in [" << x[i] << ", " << x[i + 1] << "]; y in [" << y[j] << ", " << y[j + 1] << "]" << std::endl;
      for (int m = 0; m < 4; m++) {
        for (int k = 0; k < 4; k++) {
          out << s[k] << " * x ^" << m <<  " * y ^" << k << " + ";
        }
      }
      out << std::endl;
    }
  }

  x.clear();
  y.clear();
  for (int i = 0; i < 12; i++) {
    x.push_back(-5.5 + double(i * 11) / 11);
    y.push_back(-5.5 + double(i * 11) / 11);
  }

  out << std::endl;
  out << "12x12, time : ";
  start = clock();
  splain = double_splain(double_function, x, y);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << seconds << "sec " << std::endl;
  for (int i = 0; i < x.size() - 1; i++) {
    for (int j = 0; j < y.size() - 1; j++) {
      auto s = splain[i][j];
      out << "Splain with x in [" << x[i] << ", " << x[i + 1] << "]; y in [" << y[j] << ", " << y[j + 1] << "]" << std::endl;
      for (int m = 0; m < 4; m++) {
        for (int k = 0; k < 4; k++) {
          out << s[k] << "  x ^" << m <<  " * y^" << k << " + ";
        }
      }
      out << std::endl;
    }
  }

  x.clear();
  y.clear();
  for (int i = 0; i < 18; i++) {
    x.push_back(-5.5 + double(i * 11) / 17);
    y.push_back(-5.5 + double(i * 11) / 17);
  }

  out << std::endl;
  out << "18x18, time : ";
  start = clock();
  splain = double_splain(double_function, x, y);
  end = clock();
  seconds = (double) (end - start) / CLOCKS_PER_SEC;
  out << seconds << "sec " << std::endl;
  for (int i = 0; i < x.size() - 1; i++) {
    for (int j = 0; j < y.size() - 1; j++) {
      auto s = splain[i][j];
      out << "Splain with x in [" << x[i] << ", " << x[i + 1] << "]; y in [" << y[j] << ", " << y[j + 1] << "]" << std::endl;
      for (int m = 0; m < 4; m++) {
        for (int k = 0; k < 4; k++) {
          out << s[k] << "x^" << m <<  " * y^" << k << " + ";
        }
      }
      out << std::endl;
    }
  }

  return 0;
}